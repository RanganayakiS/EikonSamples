﻿using System.Windows;
using System.Windows.Controls;

namespace AppStudioSample.Views
{
    /// <summary>
    /// Interaction logic for RealtimeView.xaml
    /// </summary>
    public partial class RealtimeView : UserControl
    {
        public RealtimeView()
        {
            if (!this.IsInDesignMode())
            {
                DataContext = new ViewModels.RealtimeViewModel();
            }
            
            InitializeComponent();
        }
    }
}
