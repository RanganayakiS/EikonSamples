﻿using System.Windows;
using System.Windows.Controls;

namespace AppStudioSample.Views
{
    /// <summary>
    /// Interaction logic for ReferenceDataView.xaml
    /// </summary>
    public partial class ReferenceDataView : UserControl
    {
        public ReferenceDataView()
        {
            if (!this.IsInDesignMode())
            {
                DataContext = new ViewModels.ReferenceDataViewModel();  
            }

            InitializeComponent();
        }
    }
}
