﻿using System.Windows;
using System.Windows.Controls;

namespace AppStudioSample.Views
{
    /// <summary>
    /// Interaction logic for TimeseriesView.xaml
    /// </summary>
    public partial class TimeseriesView : UserControl
    {
        public TimeseriesView()
        {
            if (!this.IsInDesignMode())
            {
                DataContext = new ViewModels.TimeseriesViewModel();
            }

            InitializeComponent();
        }
    }
}
