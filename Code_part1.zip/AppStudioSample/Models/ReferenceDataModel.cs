﻿using System.ComponentModel;

namespace AppStudioSample.Models
{
    public class ReferenceDataModel : INotifyPropertyChanged
    {
        private string isin;
        public string Isin
        {
            get { return isin; }
            set
            {
                isin = value;
                OnPropertyChanged("Isin");
            }
        }

        private string sedol;
        public string Sedol
        {
            get { return sedol; }
            set
            {
                sedol = value;
                OnPropertyChanged("Sedol");
            }
        }

        private string cusip;
        public string Cusip
        {
            get { return cusip; }
            set
            {
                cusip = value;
                OnPropertyChanged("Cusip");
            }
        }

        private string ticker;
        public string Ticker
        {
            get { return ticker; }
            set
            {
                ticker = value;
                OnPropertyChanged("Ticker");
            }
        }
       
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
