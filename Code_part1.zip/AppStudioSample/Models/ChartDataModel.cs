﻿using System.ComponentModel;

namespace AppStudioSample.Models
{
    public class ChartDataModel:INotifyPropertyChanged
    {
        private OxyPlot.PlotModel model;

        public OxyPlot.PlotModel Model
        {
            get { return model; }
            set
            {
                model = value;
                OnPropertyChanged("Model");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
