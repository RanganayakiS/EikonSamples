﻿using System.ComponentModel;

namespace AppStudioSample.Models
{
    public class RealtimeDataModel : INotifyPropertyChanged
    {
        private string tradePrice;
        public string TradePrice
        {
            get { return tradePrice; }
            set
            {
                tradePrice = value;
                OnPropertyChanged("TradePrice");
            }
        }

        private string tradeTime;
        public string TradeTime
        {
            get { return tradeTime; }
            set
            {
                tradeTime = value;
                OnPropertyChanged("TradeTime");
            }
        }

        private string netChange;
        public string NetChange
        {
            get { return netChange; }
            set
            {
                netChange = value;
                OnPropertyChanged("NetChange");
            }
        }

        private string bid;
        public string Bid
        {
            get { return bid; }
            set
            {
                bid = value;
                OnPropertyChanged("Bid");
            }
        }

        private string ask;
        public string Ask
        {
            get { return ask; }
            set
            {
                ask = value;
                OnPropertyChanged("Ask");
            }
        }

        private string exchangeId;
        public string ExchangeId
        {
            get { return exchangeId; }
            set
            {
                exchangeId = value;
                OnPropertyChanged("ExchangeId");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
