﻿using System.ComponentModel;

namespace AppStudioSample.Models
{
    public class GeneralInformationModel : INotifyPropertyChanged
    {
        private string instrumentCode;
        public string InstrumentCode
        {
            get { return instrumentCode; }
            set
            {
                instrumentCode = value;
                OnPropertyChanged("InstrumentCode");   
            }
        }

        private string displayName;
        public string DisplayName
        {
            get { return displayName; }
            set
            {
                displayName = value;
                OnPropertyChanged("DisplayName");
            }
        }

        private string currency;
        public string Currency  
        {
            get { return currency; }
            set
            {
                currency = value;
                OnPropertyChanged("Currency");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) 
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
