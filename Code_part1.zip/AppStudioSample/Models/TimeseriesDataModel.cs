﻿using System.ComponentModel;

namespace AppStudioSample.Models
{
    public class TimeseriesDataModel : INotifyPropertyChanged
    {
        private string timestamp;
        public string Timestamp
        {
            get { return timestamp; }
            set
            {
                timestamp = value;
                OnPropertyChanged("Timestamp");
            }
        }

        private string open;
        public string Open
        {
            get { return open; }
            set
            {
                open = value;
                OnPropertyChanged("Open");
            }
        }

        private string high;
        public string High
        {
            get { return high; }
            set
            {
                high = value;
                OnPropertyChanged("High");
            }
        }

        private string low;
        public string Low
        {
            get { return low; }
            set
            {
                low = value;
                OnPropertyChanged("Low");
            }
        }

        private string close;
        public string Close
        {
            get { return close; }
            set
            {
                close = value;
                OnPropertyChanged("Close");
            }
        }

        private string volume;
        public string Volume
        { 
            get { return volume; }
            set
            {
                volume = value;
                OnPropertyChanged("Volume");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
