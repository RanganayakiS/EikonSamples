﻿namespace AppStudioSample.Messages
{
    public enum AppState { Closing, Activated, Deactivated }

    public class AppStateChangedMessage
    {
        public AppState State { get; set; }

        public AppStateChangedMessage(AppState state) 
        {
            State = state;
        }
    }
}
