﻿namespace AppStudioSample.Messages
{
    public class InstrumentCodeChangedMessage
    {
        public string InstrumentCode { get; set; }

        public InstrumentCodeChangedMessage(string instrumentCode) 
        {
            InstrumentCode = instrumentCode;
        }
    }
}
