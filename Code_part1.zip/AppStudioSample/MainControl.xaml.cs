﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Xml;
using AppStudioSample.Messages;
using GalaSoft.MvvmLight.Messaging;
using ThomsonReuters.Eikon.Integration;
using ThomsonReuters.Desktop.SDK.DataAccess;

namespace AppStudioSample
{
    /// <summary>
    /// An App Studio application template with data access. The <see cref="EikonAppStart"/> attribute specifies the main control of your app.
    /// </summary>
    [EikonAppStart]
    public partial class MainControl
    {
        private string instrumentCode = string.Empty; 
        
        #region IAppHost

        public IAppHost AppHost { get; private set; }

        /// <summary>The default constructor.</summary>
        public MainControl()
        {
            if (!this.IsInDesignMode())
            {
                InitializeDataServices("4uAYYvoK4W");
            }
          
            InitializeComponent();
            Messenger.Default.Send(new InstrumentCodeChangedMessage("AAPL.O"));
        }

        /// <summary>The default entry point for the app, when the user opens it from the App Library.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        public MainControl(IAppHost appHost)
            : this()
        {
            AppHost = appHost;
            AppHost.Closing += AppHostOnClosing;
            
            AppHost.UserInterface.IsActivatedChanged += UserInterfaceOnIsActivatedChanged;

            AppHost.ContextService.Subscribe(SubscribeCallback);

            AppHost.CommandLine.Enable();
            AppHost.CommandLine.TextChanged += CommandLineOnTextChanged;
            AppHost.CommandLine.Text = instrumentCode;
        }

        /// <summary>The entry point for the app, opened as a part of a saved workspace with the state, that you have previously serialized.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="settingsReader">An instance of <see cref="System.Xml.XmlReader"/> with the previously serialized state.</param>
        public MainControl(IAppHost appHost, XmlReader settingsReader)
            : this(appHost)
        {

        }

        /// <summary>The entry point for the app, opened from the Related right-click menu or other navigation operation.</summary>
        /// <param name="appHost">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="context">An instance of <see cref="ThomsonReuters.Eikon.Integration.IContext"/> providing an identifier and other properties for one or many instruments in the context.</param>
        public MainControl(IAppHost appHost, IContext context)
            : this(appHost)
        {
            SubscribeCallback(context);
        }

        /// <summary>The <see cref="IAppHost.Closing"/> event handler.</summary>
        /// <param name="sender">An instance of <see cref="ThomsonReuters.Eikon.Integration.IAppHost"/> encapulating the App Studio integration services.</param>
        /// <param name="closingEventArgs">Closing event arguments.</param>
        private void AppHostOnClosing(object sender, ClosingEventArgs closingEventArgs)
        {
            Messenger.Default.Send(new AppStateChangedMessage(AppState.Closing));

            AppHost.CommandLine.TextChanged -= CommandLineOnTextChanged;
            AppHost.Closing -= AppHostOnClosing;
        }

        private void UserInterfaceOnIsActivatedChanged(object sender, IsActivatedChangedEventArgs e)
        {
            Messenger.Default.Send(new AppStateChangedMessage(e.IsActivated ? AppState.Activated : AppState.Deactivated));
        }

        private void SubscribeCallback(IContext context)
        {

            ContextEntity e = context.Entities.FirstOrDefault(entity => entity.IsSelected) ??
                              context.Entities.FirstOrDefault();

            if(e==null) return;

            instrumentCode = e.Identifier;
            PropagateInstrumentCode();
            AppHost.CommandLine.Text = e.Identifier;

        }

        private void CommandLineOnTextChanged(object sender, CommandLineTextChangedEventArgs e)
        {
            if (e.Text == "dev") return;

            instrumentCode = e.Text;
            PropagateInstrumentCode();
        }

        private void PropagateInstrumentCode()
        {
            Messenger.Default.Send(new InstrumentCodeChangedMessage(instrumentCode));
            AppHost.ContextService.Publish(instrumentCode);
        }

        #endregion

        #region IDataServices

        public IDataServices Services { get; private set; }

        /// <summary>The initialization method for the DataServices instance.</summary>
        /// <param name="appName">A <see cref="System.String"/> with your app name.</param>
        private void InitializeDataServices(string appName)
        {
            Services = DataServices.Instance;
            Services.Initialize(appName);
        }
        #endregion

       
    }
}
