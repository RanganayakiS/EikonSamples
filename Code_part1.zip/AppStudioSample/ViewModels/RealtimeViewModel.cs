﻿using System;
using System.Collections.Generic;
using System.Globalization;
using AppStudioSample.Messages;
using GalaSoft.MvvmLight;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Common;
using ThomsonReuters.Desktop.SDK.DataAccess.Realtime;
using AppStudioSample.Models;

namespace AppStudioSample.ViewModels
{
    public class RealtimeViewModel : ViewModelBase, IDisposable
    {

        public GeneralInformationModel GeneralInformation { get; set; }
        public RealtimeDataModel RealtimeData { get; set; }
               
        public RealtimeViewModel() 
        {
            GeneralInformation = new GeneralInformationModel();
            RealtimeData = new RealtimeDataModel();

            InitializeDataServices();
            InitializeMessages();
        }

        #region DataServices

        private const string DisplayName = "DSPLY_NAME";
        private const string Currency = "CF_CURR";
        private const string TradePrice = "CF_LAST";
        private const string TradeTime = "CF_TIME";
        private const string Bid = "CF_BID";
        private const string Ask = "CF_ASK";
        private const string NetChange = "CF_NETCHNG";
        private const string ExchangeId = "RDN_EXCHD2";

        private string instrumentCode;
        private IEnumerable<string> fields = new List<string> {DisplayName, Currency, TradePrice, TradeTime, Bid, Ask, NetChange, ExchangeId};

        private IRealtimeService realtimeService;
        private ServiceInformation serviceInformation;
        private IRealtimeDataSubscription subscription;

        private void InitializeDataServices() 
        {
            realtimeService = DataServices.Instance.Realtime;
            serviceInformation = realtimeService.ServiceInformation;
            realtimeService.ServiceInformationChanged += ServiceInformationChanged;
        }

        private void ServiceInformationChanged(object sender, ServiceInformationChangedEventArgs e)
        {
            serviceInformation = e.Information;

            UpdateTitle();
            UpdateSubscription();
        }

        private void Subscribe()
        {
            if (string.IsNullOrEmpty(instrumentCode) || serviceInformation.State != ServiceState.Up) return;

            Unsubscribe();

            subscription = realtimeService
                .SetupDataSubscription(instrumentCode)
                .WithFields(fields)
                .OnDataUpdated(DataUpdatedCallback)
                .OnError(ErrorCallback)
                .CreateAndStart();
        }

        private void DataUpdatedCallback(IRealtimeUpdateDictionary realtimeUpdateDictionary)
        {
            var updates = realtimeUpdateDictionary[instrumentCode];

            FieldUpdate update = null;

            GeneralInformation.InstrumentCode = instrumentCode;

            if (updates.TryGetValue(DisplayName, out update)) GeneralInformation.DisplayName = update.Value.ToString();
            if (updates.TryGetValue(Currency, out update)) GeneralInformation.Currency = update.Value.ToString();

            if (updates.TryGetValue(TradePrice, out update))
                RealtimeData.TradePrice = update.Value.IsEmpty ? string.Empty :update.Value.ToDecimal().ToString(CultureInfo.InvariantCulture);

            if (updates.TryGetValue(TradeTime, out update))
                RealtimeData.TradeTime = update.Value.ToString();

            if (updates.TryGetValue(NetChange, out update)) RealtimeData.NetChange = update.Value.ToString();
            if (updates.TryGetValue(ExchangeId, out update)) RealtimeData.ExchangeId = update.Value.ToString();

            if (updates.TryGetValue(Bid, out update)) RealtimeData.Bid = update.Value.IsEmpty ? string.Empty :update.Value.ToDecimal().ToString(CultureInfo.InvariantCulture);
            if (updates.TryGetValue(Ask, out update))
                RealtimeData.Ask = update.Value.IsEmpty
                    ? string.Empty
                    : update.Value.ToDecimal().ToString(CultureInfo.InvariantCulture);
        }

        private void ErrorCallback(RealtimeDataError realtimeDataError)
        {
            GeneralInformation.DisplayName = realtimeDataError.Message;
        }

        private void Unsubscribe()
        {
            if (subscription == null) return;

            subscription.Stop();
            subscription.Dispose();
            subscription = null;
        }

        private void UpdateSubscription()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                case ServiceState.Closing:
                    {
                        Unsubscribe();
                        break;
                    }
                case ServiceState.Up:
                default:
                    {
                        Subscribe();
                        break;
                    }
            }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value; RaisePropertyChanged("Title");
            }
        }

        private void UpdateTitle()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                    {
                        Title = "Real-time data (unavailable)";
                        break;
                    }
                case ServiceState.Closing:
                    {
                        Title = "Real-time data (closing)";
                        break;
                    }
                default:
                    {
                        {
                            Title = "Real-time data";
                            break;
                        }
                    }
            }
        }

        #endregion

        #region Messages

        private void InitializeMessages()
        {
            MessengerInstance.Register<AppStateChangedMessage>(this, AppStateChanged);
            MessengerInstance.Register<InstrumentCodeChangedMessage>(this, InstrumentCodeChanged);
        }

        private void InstrumentCodeChanged(InstrumentCodeChangedMessage msg)
        {
            instrumentCode = msg.InstrumentCode;
            UpdateSubscription();
        }

        private void AppStateChanged(AppStateChangedMessage msg)
        {
            switch (msg.State) 
            {
                case AppState.Closing:
                case AppState.Deactivated:
                    { 
                        Unsubscribe(); 
                    }
                    break;
                case AppState.Activated:
                    {
                        Subscribe();
                    }      
                    break;
                default:
                    break;
            }
        }

        #endregion

        #region IDisposable

        bool disposed;

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    realtimeService.ServiceInformationChanged -= ServiceInformationChanged;
                }

                disposed = true;
            }
        }
        #endregion
    }
}
