﻿using System;
using System.Linq;
using AppStudioSample.Messages;
using GalaSoft.MvvmLight;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Common;
using ThomsonReuters.Desktop.SDK.DataAccess.ReferenceData;
using AppStudioSample.Models;

namespace AppStudioSample.ViewModels
{
    public class ReferenceDataViewModel : ViewModelBase, IDisposable
    {
        public ReferenceDataModel ReferenceData { get; set; }

        public ReferenceDataViewModel()
        {
            ReferenceData = new ReferenceDataModel();

            InitializeDataServices();
            InitializeMessages();
        }

        #region DataServices

        private string instrumentCode;

        private IReferenceDataService referenceDataService;
        private ServiceInformation serviceInformation;
        private SymbolsRequest request;

        private void InitializeDataServices()
        {
            referenceDataService = DataServices.Instance.ReferenceData;
            serviceInformation = referenceDataService.ServiceInformation;
            referenceDataService.ServiceInformationChanged += ServiceInformationChanged;
        }

        private void ServiceInformationChanged(object sender, ServiceInformationChangedEventArgs e)
        {
            serviceInformation = e.Information;

            UpdateTitle();
            UpdateRequest();
        }

        private void Request()
        {
            if (string.IsNullOrEmpty(instrumentCode) || serviceInformation.State != ServiceState.Up) return;

            request = referenceDataService.RequestSymbols(instrumentCode, SymbolType.Ric, OnSymbolsResponse);
        }

        private void OnSymbolsResponse(SymbolsResponse response)
        {
            var s = response.Symbols.FirstOrDefault();
            
            if(s == null) return;

            ReferenceData.Isin = s.BestMatch.Isin;
            ReferenceData.Cusip = s.BestMatch.Cusip;
            ReferenceData.Sedol = s.BestMatch.Sedol;
            ReferenceData.Ticker = s.BestMatch.Ticker;
        }

        private void UpdateRequest()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                case ServiceState.Closing:
                case ServiceState.Up:
                    {
                       Request();
                       break;
                    }
            }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value; RaisePropertyChanged("Title");
            }
        }

        private void UpdateTitle()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                    {
                        Title = "Reference data (unavailable)";
                        break;
                    }
                case ServiceState.Closing:
                    {
                        Title = "Reference data (closing)";
                        break;
                    }
                default:
                    {
                        {
                            Title = "Reference data";
                            break;
                        }
                    }
            }
        }

        #endregion

        #region Messages

        private void InitializeMessages()
        {
            MessengerInstance.Register<AppStateChangedMessage>(this, AppStateChanged);
            MessengerInstance.Register<InstrumentCodeChangedMessage>(this, InstrumentCodeChanged);
        }

        private void InstrumentCodeChanged(InstrumentCodeChangedMessage msg)
        {
            instrumentCode = msg.InstrumentCode;
            Request();
        }

        private void AppStateChanged(AppStateChangedMessage msg)
        {
            switch (msg.State)
            {
                case AppState.Closing:
                case AppState.Deactivated:
                case AppState.Activated:
                    {
                        Request();
                    }
                    break;
                default:
                    break;

            }
        }

        #endregion

        #region IDisposable

        bool disposed;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    referenceDataService.ServiceInformationChanged -= ServiceInformationChanged;
                }
                disposed = true;
            }
        }
        #endregion
    }
}
