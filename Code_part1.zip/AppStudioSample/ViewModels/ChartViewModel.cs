﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using GalaSoft.MvvmLight;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.Axes;
using AppStudioSample.Messages;
using AppStudioSample.Models;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Common;
using ThomsonReuters.Desktop.SDK.DataAccess.TimeSeries;
using System.ComponentModel;

namespace AppStudioSample.ViewModels
{
    public class ChartViewModel: ViewModelBase, IDisposable
    {
        
        public ChartDataModel ChartModel { get; set; }
        
        public ChartViewModel()
        {
            ChartModel = new ChartDataModel();
            ChartModel.Model = new PlotModel();

            ChartModel.Model.Axes.Add(new LinearAxis { Position = AxisPosition.Left});
            
            InitializeDataServices();
            InitializeMessages();
        }

        #region DataService

        private string instrumentCode;

        private ITimeSeriesDataService timeseriesService;
        private ServiceInformation serviceInformation;
        private ITimeSeriesDataSubscription subscription;

        private double top = -1000;
        private double bottom = 1000;

        private void InitializeDataServices()
        {
            timeseriesService = DataServices.Instance.TimeSeries;
            serviceInformation = timeseriesService.ServiceInformation;
            timeseriesService.ServiceInformationChanged += ServiceInformationChanged;
        }

        private void ServiceInformationChanged(object sender, ServiceInformationChangedEventArgs e)
        {
            serviceInformation = e.Information;

            UpdateTitle();
            UpdateSubscription();
        }

        private void Subscribe()
        {
            if (string.IsNullOrEmpty(instrumentCode) || serviceInformation.State != ServiceState.Up) return;

            Unsubscribe();

            subscription = timeseriesService
                .SetupDataSubscription(instrumentCode)
                .WithInterval(CommonInterval.Daily)
                .OnDataReceived(DataReceivedCallback)
                .OnDataUpdated(DataUpdatedCallback)
                .CreateAndStart();
        }

        private void DataReceivedCallback(DataChunk chunk)
        {
            lock (ChartModel.Model.SyncRoot)
            {
                CandleStickAndVolumeSeries series;
                
                if (ChartModel.Model.Series.Count > 0)
                { 
                //Model.Series.Add(series);
                    series = (CandleStickAndVolumeSeries)ChartModel.Model.Series[0];
                }
                else
                {
                    series = new CandleStickAndVolumeSeries() {Title = "Intraday 1M"};
                    ChartModel.Model.Series.Add(series);
                }

                double highest = top;
                double lowest = bottom;

                foreach (IBarData bar in chunk.Records.ToBarRecords())
                {
                    series.Items.Add(new OhlcvItem
                    {
                        X = bar.Timestamp.Value.Ticks,
                        Open = bar.Open.Value,
                        High = bar.High.Value,
                        Low = bar.Low.Value,
                        Close = bar.Close.Value,
                        BuyVolume = bar.Volume.Value
                    });
                   
                    if (bar.High.HasValue)
                    {
                        if (bar.High.Value > highest)
                        {
                            highest = bar.High.Value;
                        }
                    }

                    if (bar.Low.HasValue)
                    {
                        if (bar.Low.Value < lowest)
                        {
                            lowest = bar.Low.Value;
                        }
                    }
                }

                if (top != highest)
                {
                    top = highest;
                    ChartModel.Model.Axes[0].Maximum = top;
                }
                if (bottom != lowest)
                {
                    bottom = lowest;
                    ChartModel.Model.Axes[0].Minimum = bottom;
                }
                
                OnPropertyChanged("Model");

            }
            ChartModel.Model.InvalidatePlot(true);
            
        }

        private void DataUpdatedCallback(IDataUpdate update)
        {
            IData record = update.Records.FirstOrDefault();
            bool success = false;
            if (record != null)
            {
                IBarData bar = record.ToBarRecord();


                lock (ChartModel.Model.SyncRoot)
                {
                    CandleStickAndVolumeSeries series;

                    if (ChartModel.Model.Series.Count > 0)
                    {
                        series = (CandleStickAndVolumeSeries)ChartModel.Model.Series[0];
                    }
                    else
                    {
                        series = new CandleStickAndVolumeSeries() { Title = instrumentCode };
                        ChartModel.Model.Series.Add(series);
                    }

                    if (bar.Timestamp.HasValue && bar.Open.HasValue && bar.High.HasValue && bar.Low.HasValue && bar.Close.HasValue && bar.Volume.HasValue)
                    {
                        if (update.UpdateType == UpdateType.ExistingPoint && series.Items.Count > 0)
                            series.Items.RemoveAt(series.Items.Count - 1);
                        
                        series.Items.Add(new OhlcvItem
                        {
                            X = bar.Timestamp.Value.Ticks,
                            Open = bar.Open.Value,
                            High = bar.High.Value,
                            Low = bar.Low.Value,
                            Close = bar.Close.Value,
                            BuyVolume = bar.Volume.Value
                        });
                        OnPropertyChanged("Model");
                    }
                }

                    
                    
                    
                
                ChartModel.Model.InvalidatePlot(true);
            }
        }



        private void Unsubscribe()
        {
            for (int i = 0; i < ChartModel.Model.Series.Count; i++)
            {
                ChartModel.Model.Series.RemoveAt(i);
            }
            
          
            if (subscription == null) return;

            subscription.Stop();
            subscription.Dispose();
            subscription = null;
        }

        private void UpdateSubscription()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                case ServiceState.Closing:
                    {
                        Unsubscribe();
                        break;
                    }
                case ServiceState.Up:
                    {
                        Subscribe();
                        break;
                    }
            }
        }

        private void UpdateTitle()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                    {
                        ChartModel.Model.Title = "Timeseries data (unavailable)";
                        break;
                    }
                case ServiceState.Closing:
                    {
                        ChartModel.Model.Title = "Timeseries data (closing)";
                        break;
                    }
                default:
                    {
                        {
                            ChartModel.Model.Title = instrumentCode;
                            break;
                        }
                    }
            }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Messages

        private void InitializeMessages()
        {
            MessengerInstance.Register<AppStateChangedMessage>(this, AppStateChanged);
            MessengerInstance.Register<InstrumentCodeChangedMessage>(this, InstrumentCodeChanged);
        }

        private void InstrumentCodeChanged(InstrumentCodeChangedMessage msg)
        {
            instrumentCode = msg.InstrumentCode;
            ChartModel.Model.Title = instrumentCode;
            UpdateSubscription();
        }

        private void AppStateChanged(AppStateChangedMessage msg)
        {
            switch (msg.State)
            {
                case AppState.Closing:
                case AppState.Deactivated:
                    {
                        Unsubscribe();
                    }
                    break;
                case AppState.Activated:
                    {
                        Subscribe();
                    }
                    break;
                default:
                    break;

            }
        }

        #endregion

        #region IDisposable

        bool disposed;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    timeseriesService.ServiceInformationChanged -= ServiceInformationChanged;
                }
                disposed = true;
            }
        }
        #endregion
    }
}
