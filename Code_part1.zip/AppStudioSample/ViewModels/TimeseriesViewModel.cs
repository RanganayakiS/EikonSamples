﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using AppStudioSample.Messages;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Messaging;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Common;
using ThomsonReuters.Desktop.SDK.DataAccess.TimeSeries;
using AppStudioSample.Models;


namespace AppStudioSample.ViewModels
{
    public class TimeseriesViewModel : ViewModelBase, IDisposable
    {
        public ObservableCollection<TimeseriesDataModel> TimeseriesData { get; private set; }

        public TimeseriesViewModel()
        {
            TimeseriesData = new ObservableCollection<TimeseriesDataModel>();

            InitializeDataServices();
            InitializeMessages();
        }

        #region DataService

        private string instrumentCode;

        private ITimeSeriesDataService timeseriesService;
        private ServiceInformation serviceInformation;
        private ITimeSeriesDataSubscription subscription;

        private void InitializeDataServices()
        {
            timeseriesService = DataServices.Instance.TimeSeries;
            serviceInformation = timeseriesService.ServiceInformation;
            timeseriesService.ServiceInformationChanged += ServiceInformationChanged;
        }

        private void ServiceInformationChanged(object sender, ServiceInformationChangedEventArgs e)
        {
            serviceInformation = e.Information;

            UpdateTitle();
            UpdateSubscription();
        }

        private void Subscribe() 
        {
            if (string.IsNullOrEmpty(instrumentCode) || serviceInformation.State != ServiceState.Up) return;

            Unsubscribe();

            subscription = timeseriesService
                .SetupDataSubscription(instrumentCode)
                .WithInterval(CommonInterval.Daily)
                .OnDataReceived(DataReceivedCallback)
                .OnDataUpdated(DataUpdatedCallback)
                .CreateAndStart();
        }

        private void DataReceivedCallback(DataChunk chunk) 
        {
            foreach (IBarData bar in chunk.Records.ToBarRecords()) 
            {
                TimeseriesDataModel m = new TimeseriesDataModel
                {
                    Timestamp = bar.Timestamp.HasValue ? bar.Timestamp.Value.ToShortDateString() : String.Empty,
                    Open = bar.Open.HasValue ? bar.Open.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    High = bar.High.HasValue ? bar.High.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Low = bar.Low.HasValue ? bar.Low.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Close = bar.Close.HasValue ? bar.Close.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Volume = bar.Volume.HasValue ? bar.Volume.Value.ToString(CultureInfo.InvariantCulture) : String.Empty
                };

                TimeseriesData.Insert(0, m);
            }
        }

        private void DataUpdatedCallback(IDataUpdate update) 
        {
            IData record = update.Records.FirstOrDefault();
            
            if (record != null) 
            {
                IBarData bar = record.ToBarRecord();
    
                if (update.UpdateType == UpdateType.ExistingPoint && TimeseriesData.Count > 0)
                    TimeseriesData.RemoveAt(0);

                TimeseriesDataModel m = new TimeseriesDataModel
                {
                    Timestamp = bar.Timestamp.HasValue ? bar.Timestamp.Value.ToShortDateString() : String.Empty,
                    Open = bar.Open.HasValue ? bar.Open.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    High = bar.High.HasValue ? bar.High.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Low = bar.Low.HasValue ? bar.Low.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Close = bar.Close.HasValue ? bar.Close.Value.ToString(CultureInfo.InvariantCulture) : String.Empty,
                    Volume = bar.Volume.HasValue ? bar.Volume.Value.ToString(CultureInfo.InvariantCulture) : String.Empty
                };

                TimeseriesData.Insert(0, m);   
            }
        }


        private void Unsubscribe() 
        {
            TimeseriesData.Clear();

            if (subscription == null) return;
            
            subscription.Stop();
            subscription.Dispose();
            subscription = null;
        }

        private void UpdateSubscription()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                case ServiceState.Closing:
                    {
                        Unsubscribe();
                        break;
                    }
                case ServiceState.Up:
                    {
                        Subscribe();
                        break;
                    }
            }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value; this.RaisePropertyChanged("Title");
            }
        }

        private void UpdateTitle()
        {
            switch (serviceInformation.State)
            {
                case ServiceState.None:
                case ServiceState.Down:
                    {
                        Title = "Timeseries data (unavailable)";
                        break;
                    }
                case ServiceState.Closing:
                    {
                        Title = "Timeseries data (closing)";
                        break;
                    }
                default:
                    {
                        {
                            Title = "Timeseries data";
                            break;
                        }
                    }
            }
        }

        #endregion

        #region Messages

        private void InitializeMessages()
        {
            MessengerInstance.Register<AppStateChangedMessage>(this, AppStateChanged);
            MessengerInstance.Register<InstrumentCodeChangedMessage>(this, InstrumentCodeChanged);
        }

        private void InstrumentCodeChanged(InstrumentCodeChangedMessage msg)
        {
            instrumentCode = msg.InstrumentCode;
            UpdateSubscription();
        }

        private void AppStateChanged(AppStateChangedMessage msg)
        {
            switch (msg.State)
            {
                case AppState.Closing:
                case AppState.Deactivated:
                    {
                        Unsubscribe();
                    }
                    break;
                case AppState.Activated:
                    {
                        Subscribe();
                    }
                    break;
                default:
                    break;

            }
        }

        #endregion

        #region IDisposable

        bool disposed;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    timeseriesService.ServiceInformationChanged -= ServiceInformationChanged;
                }
                disposed = true;
            }
        }
        #endregion
    }
}
